"use client";

import { AccountSettingsPanel } from "@/components/profile/settings/account-settings-panel";
import { FavoritesSettingsPanel } from "@/components/profile/settings/favorites-settings-panel";
import { HelpSettingsPanel } from "@/components/profile/settings/help-settings-panel";
import { NotificationsSettingsPanel } from "@/components/profile/settings/notifications-settings-panel";
import { PaymentsSettingsPanel } from "@/components/profile/settings/payments-settings-panel";
import { PrivacySettingsPanel } from "@/components/profile/settings/privacy-settings-panel";
import { SavedQuotesSettingsPanel } from "@/components/profile/settings/saved-quotes-settings-panel";
import { SecuritySettingsPanel } from "@/components/profile/settings/security-settings-panel";
import type { SettingsPanelId } from "@/types/user-settings";

interface ProfileSettingsViewProps {
  panel: SettingsPanelId;
  onClose: () => void;
}

export function ProfileSettingsView({
  panel,
  onClose,
}: ProfileSettingsViewProps) {
  switch (panel) {
    case "savedQuotes":
      return <SavedQuotesSettingsPanel onBack={onClose} />;
    case "settings":
      return <AccountSettingsPanel onBack={onClose} />;
    case "favorites":
      return <FavoritesSettingsPanel onBack={onClose} />;
    case "payments":
      return <PaymentsSettingsPanel onBack={onClose} />;
    case "help":
      return <HelpSettingsPanel onBack={onClose} />;
    case "privacy":
      return <PrivacySettingsPanel onBack={onClose} />;
    case "notifications":
      return <NotificationsSettingsPanel onBack={onClose} />;
    case "security":
      return <SecuritySettingsPanel onBack={onClose} />;
    default:
      return null;
  }
}
