"use client";

import { DistanceBadge } from "@/components/explore/distance-badge";
import { SoftNavLink } from "@/components/navigation/soft-nav-link";
import {
  ImageCarousel,
  uniqueImages,
} from "@/components/ui/image-carousel";
import { cn, getLocationPricePresentation } from "@/lib/utils";
import type { ContactPreview, Location } from "@/types/location";
import { GitCompareArrows, Heart, MapPin } from "lucide-react";
import { memo, useMemo, useState } from "react";

interface LocationCardProps {
  location: Location;
  isFavorite: boolean;
  isCompareSelected: boolean;
  onToggleFavorite: (id: string) => void;
  onToggleCompare: (id: string) => void;
  href?: string;
}

export const LocationCard = memo(function LocationCard({
  location,
  isFavorite,
  isCompareSelected,
  onToggleFavorite,
  onToggleCompare,
  href = `/location/${location.id}`,
}: LocationCardProps) {
  const { contactsBeenHere } = location;
  const hasContacts = contactsBeenHere.count > 0;
  const price = getLocationPricePresentation(location);
  const [contactsOpen, setContactsOpen] = useState(false);
  const photos = useMemo(
    () => uniqueImages([location.imageUrl, ...(location.gallery ?? [])]),
    [location.gallery, location.imageUrl],
  );

  return (
    <article className="render-contained h-full overflow-hidden rounded-2xl border border-primary-black/12 bg-background shadow-sm transition-[border-color,transform,box-shadow] duration-150 hover:border-primary-black active:scale-[0.995]">
      <div className="relative">
        <ImageCarousel
          images={photos}
          alt={location.name}
          frameClassName="aspect-[16/10]"
          sizes="(max-width: 448px) 100vw, 448px"
          showDots={photos.length > 1}
          renderSlide={(_image, _index, imageNode) => (
            <SoftNavLink href={href} className="absolute inset-0 block">
              {imageNode}
            </SoftNavLink>
          )}
        />

        {location.distanceBadge && (
          <div className="absolute left-3 top-3 z-10">
            <DistanceBadge label={location.distanceBadge} />
          </div>
        )}

        <div className="absolute right-3 top-3 z-10 flex gap-2">
          <button
            type="button"
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              onToggleCompare(location.id);
            }}
            aria-label={
              isCompareSelected
                ? `Rimuovi ${location.name} dal confronto`
                : `Aggiungi ${location.name} al confronto`
            }
            className={cn(
              "flex h-9 w-9 items-center justify-center rounded-full shadow-md backdrop-blur-md transition-colors duration-150",
              isCompareSelected
                ? "bg-brand-teal-strong text-ink-inverse"
                : "bg-surface text-brand-teal-strong hover:bg-brand-teal/10",
            )}
          >
            <GitCompareArrows
              className="h-4 w-4"
              strokeWidth={2.75}
              aria-hidden
            />
          </button>
          <button
            type="button"
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              onToggleFavorite(location.id);
            }}
            aria-label={
              isFavorite
                ? `Rimuovi ${location.name} dai preferiti`
                : `Aggiungi ${location.name} ai preferiti`
            }
            className={cn(
              "flex h-9 w-9 items-center justify-center rounded-full shadow-md backdrop-blur-md transition-colors duration-150",
              isFavorite
                ? "bg-brand-pink text-white"
                : "bg-surface text-primary-black hover:bg-surface/90",
            )}
          >
            <Heart
              className="h-4 w-4"
              strokeWidth={2.75}
              fill={isFavorite ? "currentColor" : "none"}
              aria-hidden
            />
          </button>
        </div>
      </div>

      <SoftNavLink href={href} className="block p-4">
        <div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between sm:gap-3">
          <div className="min-w-0">
            <h3 className="truncate font-semibold text-primary-black">
              {location.name}
            </h3>
            <p className="mt-0.5 flex min-w-0 items-center gap-1 text-xs text-primary-black/50">
              <MapPin className="h-3 w-3 shrink-0" aria-hidden />
              <span className="truncate">
                {location.zoneLabel} · {location.comune} · fino a{" "}
                {location.capacity} ospiti
              </span>
            </p>
          </div>
          <p className="shrink-0 self-start sm:text-right">
            <span className="rounded-full bg-paper px-3 py-1 text-xs font-bold text-ink-inverse">
              {price.eyebrow} {price.price}
            </span>
            <span className="mt-1 block text-[10px] font-bold text-primary-black/50">
              {price.unit}
            </span>
            <span className="mt-1 block text-[10px] text-brand-teal">
              {price.badge}
            </span>
          </p>
        </div>
      </SoftNavLink>

      {hasContacts && (
        <div className="px-4 pb-4">
          <button
            type="button"
            onClick={() => setContactsOpen((current) => !current)}
            className={cn(
              "w-full rounded-xl bg-brand-teal px-3 py-2.5 text-left transition-all duration-150 hover:bg-brand-teal-strong",
              contactsOpen && "rounded-2xl py-3",
            )}
            aria-expanded={contactsOpen}
          >
            <span className="flex items-center gap-2">
              <span className="flex -space-x-2">
                {contactsBeenHere.contacts.slice(0, 3).map((contact) => (
                  <ContactAvatar
                    key={contact.id}
                    contact={contact}
                    size="sm"
                    className="border-2 border-white/85"
                  />
                ))}
              </span>
              <span className="text-[11px] leading-tight text-ink-inverse/85">
                <span className="font-semibold text-ink-inverse">
                  {contactsBeenHere.count}
                </span>{" "}
                {contactsBeenHere.count === 1
                  ? "tuo contatto è stato qui"
                  : "tuoi contatti sono stati qui"}
              </span>
            </span>

            {contactsOpen && (
              <span className="mt-3 block border-t border-ink-inverse/20 pt-3">
                <span className="block text-[10px] font-black uppercase tracking-[0.14em] text-ink-inverse/80">
                  Chi è stato qui
                </span>
                <span className="mt-2 flex flex-wrap gap-2">
                  {contactsBeenHere.contacts.map((contact) => (
                    <span
                      key={contact.id}
                      className="inline-flex items-center gap-1.5 rounded-full bg-ink-inverse/10 px-2 py-1 text-xs font-bold text-ink-inverse"
                    >
                      <ContactAvatar contact={contact} size="xs" />
                      {contact.name}
                    </span>
                  ))}
                </span>
              </span>
            )}
          </button>
        </div>
      )}
    </article>
  );
});

function ContactAvatar({
  contact,
  size = "sm",
  className,
}: {
  contact: ContactPreview;
  size?: "xs" | "sm";
  className?: string;
}) {
  const sizeClass = size === "xs" ? "h-5 w-5 text-[8px]" : "h-6 w-6 text-[9px]";

  if (contact.avatarUrl) {
    return (
      // eslint-disable-next-line @next/next/no-img-element
      <img
        src={contact.avatarUrl}
        alt=""
        title={contact.name}
        className={cn(
          "shrink-0 rounded-full object-cover",
          sizeClass,
          className,
        )}
      />
    );
  }

  return (
    <span
      className={cn(
        "flex shrink-0 items-center justify-center rounded-full font-bold text-white",
        sizeClass,
        className,
      )}
      style={{ backgroundColor: contact.avatarColor }}
      title={contact.name}
    >
      {contact.initials}
    </span>
  );
}
