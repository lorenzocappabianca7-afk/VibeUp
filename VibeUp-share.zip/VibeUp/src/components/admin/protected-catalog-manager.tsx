"use client";

import { Button } from "@/components/ui/button";
import { SafeImage } from "@/components/ui/safe-image";
import { useAppState } from "@/context/app-state-context";
import { canAccessAdminCatalog } from "@/lib/admin-access";
import { APP_SHELL_WIDTH_CLASS, cn } from "@/lib/utils";
import type {
  ManagedListing,
  ManagedServiceListing,
} from "@/types/admin";
import {
  getManagedListingStatus,
  isManagedListingLive,
} from "@/types/admin";
import type { ExploreCategory } from "@/types/location";
import type { LucideIcon } from "lucide-react";
import {
  ArrowLeft,
  Building2,
  Camera,
  Disc3,
  ClipboardCheck,
  Eye,
  EyeOff,
  Gift,
  Lock,
  Mail,
  Music,
  Pencil,
  Plus,
  Trash2,
  UploadCloud,
  Wand2,
  X,
} from "lucide-react";
import { AdminLocationPublishPanel } from "@/components/admin/admin-location-publish-panel";
import { AdminProposalsPanel } from "@/components/admin/admin-proposals-panel";
import { uploadListingPhotos } from "@/lib/storage/upload-client";
import Link from "next/link";
import { useMemo, useRef, useState } from "react";

const CATEGORIES: {
  id: ExploreCategory;
  label: string;
  icon: LucideIcon;
}[] = [
  { id: "locali", label: "Locali", icon: Building2 },
  { id: "dj", label: "DJ", icon: Disc3 },
  { id: "fotografo", label: "Fotografi", icon: Camera },
  { id: "decorazioni", label: "Decorazioni", icon: Gift },
  { id: "altri", label: "Altri servizi", icon: Music },
];

const EMPTY_SERVICE_FORM = {
  name: "",
  description: "",
  providerZone: "Torino",
  price: "250",
  priceSuffix: "servizio",
  imageUrl: "",
  uploadedImageUrl: "",
  galleryImageUrls: [] as string[],
};


function listingName(listing: ManagedListing): string {
  return listing.category === "locali"
    ? listing.location.name
    : listing.name;
}

function parseEuroAmount(value: string): number | null {
  const match = value.match(/(?:€|euro)?\s*(\d{2,5})(?:[,.](\d{1,2}))?/i);
  if (!match) return null;

  const euros = Number(match[1]);
  const cents = match[2] ? Number(match[2].padEnd(2, "0")) / 100 : 0;
  return euros + cents;
}

async function readImportText(files?: FileList | null): Promise<string> {
  const fileTexts = await Promise.all(
    Array.from(files ?? []).map(async (file) => {
      if (
        file.type.startsWith("text/") ||
        file.name.endsWith(".txt") ||
        file.name.endsWith(".csv") ||
        file.name.endsWith(".md")
      ) {
        return file.text();
      }
      return `File caricato: ${file.name}`;
    }),
  );

  return fileTexts.join("\n");
}

export function ProtectedCatalogManager() {
  const {
    currentUser,
    managedListings,
    upsertManagedListing,
    removeManagedListing,
    toggleManagedListingPublication,
  } = useAppState();
  const [activeCategory, setActiveCategory] = useState<ExploreCategory>("locali");
  const [adminSection, setAdminSection] = useState<"catalog" | "proposals">(
    "catalog",
  );
  const [serviceForm, setServiceForm] = useState(EMPTY_SERVICE_FORM);
  const [editingServiceId, setEditingServiceId] = useState<string | null>(null);
  const [aiText, setAiText] = useState("");
  const [aiLoading, setAiLoading] = useState(false);
  const [aiMessage, setAiMessage] = useState<string | null>(null);
  const [photoUploading, setPhotoUploading] = useState(false);
  const serviceFormRef = useRef<HTMLElement>(null);

  const categoryListings = useMemo(
    () =>
      managedListings
        .filter((listing) => listing.category === activeCategory)
        .sort(
          (a, b) =>
            new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime(),
        ),
    [managedListings, activeCategory],
  );

  const liveCount = useMemo(
    () => categoryListings.filter((listing) => isManagedListingLive(listing)).length,
    [categoryListings],
  );

  function resetServiceForm() {
    setServiceForm(EMPTY_SERVICE_FORM);
    setEditingServiceId(null);
    setAiText("");
  }

  function selectCategory(category: ExploreCategory) {
    setActiveCategory(category);
    resetServiceForm();
    setAiMessage(null);
  }

  function loadServiceListing(listing: ManagedServiceListing) {
    setEditingServiceId(listing.id);
    setServiceForm({
      name: listing.name,
      description: listing.description,
      providerZone: listing.providerZone,
      price: String(listing.price || 0),
      priceSuffix: listing.priceSuffix || "servizio",
      imageUrl: listing.imageUrl?.startsWith("data:")
        ? ""
        : listing.imageUrl ?? "",
      uploadedImageUrl: listing.imageUrl?.startsWith("data:")
        ? listing.imageUrl
        : "",
      galleryImageUrls: listing.galleryImageUrls ?? [],
    });
    setAiMessage(`Modifica caricata: ${listing.name}`);
    requestAnimationFrame(() => {
      serviceFormRef.current?.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
    });
  }

  if (!canAccessAdminCatalog(currentUser.email, currentUser.role)) {
    return (
      <div
        className={cn(
          "mx-auto box-border min-h-dvh min-w-0 overflow-x-clip bg-background px-4 pt-8",
          APP_SHELL_WIDTH_CLASS,
        )}
      >
        <div className="rounded-[2rem] border border-primary-black/10 bg-primary-black/[0.02] p-6">
          <Link
            href="/"
            className="mb-5 inline-flex items-center gap-1.5 rounded-full bg-background px-3 py-2 text-xs font-bold text-primary-black/55 transition-colors hover:text-primary-black"
          >
            <ArrowLeft className="h-3.5 w-3.5" aria-hidden />
            Torna alla home
          </Link>
          <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white/12 text-primary-black">
            <Lock className="h-5 w-5" aria-hidden />
          </span>
          <h1 className="mt-4 text-2xl font-black text-primary-black">
            Accesso non autorizzato
          </h1>
          <p className="mt-2 text-sm leading-relaxed text-primary-black/60">
            Accedi con l&apos;account admin (
            vibeup.planner@gmail.com oppure un profilo con ruolo{" "}
            <span className="font-semibold">admin</span> su Supabase).
          </p>
        </div>
      </div>
    );
  }

  function saveService(published = false) {
    if (activeCategory === "locali") return;

    const listing: ManagedServiceListing = {
      id: editingServiceId ?? `managed-${activeCategory}-${Date.now()}`,
      category: activeCategory,
      name: serviceForm.name.trim() || "Nuovo servizio",
      description:
        serviceForm.description.trim() ||
        "Servizio gestito dal catalogo privato VibeUp.",
      providerZone: serviceForm.providerZone.trim() || "Torino",
      price: Number(serviceForm.price) || 0,
      priceSuffix: serviceForm.priceSuffix.trim() || "servizio",
      imageUrl:
        serviceForm.uploadedImageUrl || serviceForm.imageUrl.trim() || undefined,
      galleryImageUrls:
        serviceForm.galleryImageUrls.length > 0
          ? serviceForm.galleryImageUrls
          : serviceForm.uploadedImageUrl
            ? [serviceForm.uploadedImageUrl]
            : serviceForm.imageUrl.trim()
              ? [serviceForm.imageUrl.trim()]
              : undefined,
      published,
      status: published ? "published" : "draft",
      updatedAt: new Date().toISOString(),
    };

    const wasEditing = Boolean(editingServiceId);
    upsertManagedListing(listing);
    resetServiceForm();
    setAiMessage(
      wasEditing
        ? published
          ? "Pubblicazione aggiornata e online in Esplora."
          : "Modifiche salvate in bozza."
        : published
          ? "Servizio pubblicato in Esplora. Lo trovi nell’elenco a destra."
          : "Bozza salvata. Puoi modificarla o pubblicarla quando vuoi.",
    );
  }

  async function addServicePhoto(files?: FileList | null) {
    setPhotoUploading(true);
    setAiMessage(null);
    const result = await uploadListingPhotos(files, {
      folder: `services/${activeCategory}`,
    });
    setPhotoUploading(false);

    if (!result.ok) {
      setAiMessage(result.error);
      return;
    }

    const images = result.urls;
    setServiceForm((prev) => ({
      ...prev,
      uploadedImageUrl:
        activeCategory === "decorazioni"
          ? prev.uploadedImageUrl || images[0]
          : images[0],
      galleryImageUrls:
        activeCategory === "decorazioni"
          ? [...prev.galleryImageUrls, ...images]
          : images.slice(0, 1),
    }));
    setAiMessage(
      activeCategory === "decorazioni"
        ? `${images.length} foto caricate su cloud.`
        : "Foto profilo caricata su cloud.",
    );
  }

  function removeServicePhoto(index: number) {
    setServiceForm((prev) => {
      const galleryImageUrls = prev.galleryImageUrls.filter(
        (_, itemIndex) => itemIndex !== index,
      );
      return {
        ...prev,
        galleryImageUrls,
        uploadedImageUrl: galleryImageUrls[0] ?? "",
      };
    });
  }

  async function importServiceDetails(files?: FileList | null) {
    if (activeCategory === "locali") return;

    setAiLoading(true);
    setAiMessage(null);

    try {
      const importedText = await readImportText(files);
      const sourceText = [aiText, importedText].filter(Boolean).join("\n");
      const lines = sourceText
        .split(/\r?\n/)
        .map((line) => line.trim())
        .filter(Boolean);
      const inferredName =
        lines.find((line) => !parseEuroAmount(line) && line.length <= 60) ??
        serviceForm.name;
      const inferredPrice =
        parseEuroAmount(sourceText) ?? Number(serviceForm.price) ?? 0;
      const zoneLine = lines.find((line) =>
        /torino|piemonte|provincia|zona|cintura/i.test(line),
      );

      setServiceForm((prev) => ({
        ...prev,
        name: inferredName || prev.name,
        description: sourceText || prev.description,
        providerZone: zoneLine ?? prev.providerZone,
        price: inferredPrice ? String(Math.round(inferredPrice)) : prev.price,
      }));
      setAiMessage(
        "Dettagli servizio importati. Controllali e poi salva o pubblica.",
      );
    } catch {
      setAiMessage(
        "Non sono riuscito a leggere il materiale. Puoi incollare il testo o completare i campi a mano.",
      );
    } finally {
      setAiLoading(false);
    }
  }

  const isLocationCategory = activeCategory === "locali";

  return (
    <div
      className={cn(
        "mx-auto box-border min-h-dvh min-w-0 overflow-x-clip bg-background px-4 py-6 pb-8 sm:px-5 lg:px-8",
        APP_SHELL_WIDTH_CLASS,
      )}
    >
      <header className="flex min-w-0 flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div className="min-w-0">
          <Link
            href="/"
            className="mb-3 inline-flex items-center gap-1.5 text-xs font-bold text-primary-black/45 transition-colors hover:text-primary-black"
          >
            <ArrowLeft className="h-3.5 w-3.5" aria-hidden />
            Torna alla home
          </Link>
          <p className="text-xs font-bold uppercase tracking-[0.2em] text-brand-teal">
            Catalogo privato
          </p>
          <h1 className="mt-1 break-words text-2xl font-black text-primary-black sm:text-3xl">
            Gestione pubblicazioni VibeUp
          </h1>
          <p className="mt-1 text-sm text-primary-black/60">
            Accesso con account admin autenticato. Qui restano salvate tutte le
            tue pubblicazioni: puoi rivederle e modificarle quando vuoi.
          </p>
        </div>
      </header>

      <div className="mt-6 flex flex-wrap gap-2">
        <button
          type="button"
          onClick={() => setAdminSection("catalog")}
          className={cn(
            "rounded-2xl px-4 py-2.5 text-sm font-bold transition-colors",
            adminSection === "catalog"
              ? "bg-paper text-ink-inverse"
              : "bg-primary-black/[0.04] text-primary-black/65",
          )}
        >
          Catalogo
        </button>
        <button
          type="button"
          onClick={() => setAdminSection("proposals")}
          className={cn(
            "inline-flex items-center gap-2 rounded-2xl px-4 py-2.5 text-sm font-bold transition-colors",
            adminSection === "proposals"
              ? "bg-brand-teal text-primary-black"
              : "bg-primary-black/[0.04] text-primary-black/65",
          )}
        >
          <ClipboardCheck className="h-4 w-4" aria-hidden />
          Proposte da validare
        </button>
      </div>

      {adminSection === "proposals" ? (
        <AdminProposalsPanel />
      ) : (
        <>
      <div className="mt-6 min-w-0 max-w-full overflow-x-auto overscroll-x-contain rounded-3xl bg-primary-black/[0.04] p-2 [-webkit-overflow-scrolling:touch]">
        <div className="flex w-max max-w-none gap-2">
          {CATEGORIES.map((category) => {
            const Icon = category.icon;
            return (
              <button
                key={category.id}
                type="button"
                onClick={() => selectCategory(category.id)}
                className={cn(
                  "flex shrink-0 items-center gap-2 rounded-2xl px-3.5 py-2.5 text-sm font-bold transition-colors sm:px-4",
                  activeCategory === category.id
                    ? "bg-brand-teal text-ink-inverse"
                    : "bg-background text-primary-black/65",
                )}
              >
                <Icon className="h-4 w-4" aria-hidden />
                {category.label}
              </button>
            );
          })}
        </div>
      </div>

      {aiMessage && (
        <p className="mt-4 rounded-2xl bg-brand-teal/10 px-4 py-3 text-xs font-semibold text-primary-black/70">
          {aiMessage}
        </p>
      )}

      {isLocationCategory ? (
        <div className="mt-6">
          <AdminLocationPublishPanel onMessage={setAiMessage} />
        </div>
      ) : (
      <div className="mt-6 grid min-w-0 gap-5 lg:grid-cols-[1.1fr_0.9fr]">
        <section
          ref={serviceFormRef}
          className="min-w-0 rounded-[1.75rem] border border-primary-black/10 bg-surface p-4 shadow-sm sm:rounded-[2rem] sm:p-5"
        >
          <div className="flex min-w-0 items-center gap-2">
            {editingServiceId ? (
              <Pencil className="h-5 w-5 shrink-0 text-brand-teal" aria-hidden />
            ) : (
              <Plus className="h-5 w-5 shrink-0 text-brand-teal" aria-hidden />
            )}
            <h2 className="min-w-0 text-base font-black text-primary-black sm:text-lg">
              {editingServiceId ? "Modifica pubblicazione" : "Nuova pubblicazione"}
            </h2>
          </div>
          {editingServiceId && (
            <p className="mt-1 text-xs font-semibold text-primary-black/55">
              Stai aggiornando una pubblicazione già salvata. Le modifiche
              sostituiscono la versione precedente.
            </p>
          )}

          <div className="mt-4 space-y-4">
              <div className="rounded-3xl border border-dashed border-brand-teal/35 bg-brand-teal/5 p-4">
                <div className="flex items-start gap-3">
                  <UploadCloud className="mt-0.5 h-5 w-5 text-brand-teal" aria-hidden />
                  <div>
                    <p className="text-sm font-bold text-primary-black">
                      Importa dettagli servizio con IA
                    </p>
                    <p className="mt-1 text-xs text-primary-black/60">
                      Incolla una mail, un testo o carica uno screen/listino per precompilare nome, descrizione, zona e prezzo.
                    </p>
                  </div>
                </div>
                <textarea
                  value={aiText}
                  onChange={(event) => setAiText(event.target.value)}
                  rows={4}
                  placeholder="Incolla qui testo, mail o dettagli del servizio..."
                  className="mt-3 w-full min-w-0 rounded-2xl border border-primary-black/10 bg-background px-4 py-3 text-base outline-none focus:border-brand-teal"
                />
                <div className="mt-3 flex flex-col gap-2 sm:flex-row">
                  <label className="flex flex-1 cursor-pointer items-center justify-center gap-2 rounded-2xl border border-primary-black/10 bg-background px-4 py-3 text-sm font-bold text-primary-black/70">
                    <Mail className="h-4 w-4" aria-hidden />
                    Carica screen/documento
                    <input
                      type="file"
                      multiple
                      accept="image/*,.pdf,.txt,.csv,.md"
                      className="sr-only"
                      onChange={(event) => void importServiceDetails(event.target.files)}
                    />
                  </label>
                  <Button
                    className="flex-1 rounded-2xl"
                    disabled={aiLoading}
                    onClick={() => void importServiceDetails()}
                  >
                    <Wand2 className="mr-2 h-4 w-4" aria-hidden />
                    {aiLoading ? "Analisi IA..." : "Apprendi dettagli"}
                  </Button>
                </div>
                {aiMessage && (
                  <p className="mt-3 text-xs font-semibold text-primary-black/60">
                    {aiMessage}
                  </p>
                )}
              </div>

              <FormInput label="Nome" value={serviceForm.name} onChange={(value) => setServiceForm((prev) => ({ ...prev, name: value }))} />
              <FormTextarea label="Descrizione" value={serviceForm.description} onChange={(value) => setServiceForm((prev) => ({ ...prev, description: value }))} />
              <div className="grid gap-3 sm:grid-cols-3">
                <FormInput label="Zona" value={serviceForm.providerZone} onChange={(value) => setServiceForm((prev) => ({ ...prev, providerZone: value }))} />
                <FormInput label="Prezzo" type="number" value={serviceForm.price} onChange={(value) => setServiceForm((prev) => ({ ...prev, price: value }))} />
                <FormInput label="Unita prezzo" value={serviceForm.priceSuffix} onChange={(value) => setServiceForm((prev) => ({ ...prev, priceSuffix: value }))} />
              </div>
              <FormInput
                label={
                  activeCategory === "decorazioni"
                    ? "URL foto negozio"
                    : activeCategory === "dj" || activeCategory === "fotografo"
                      ? "URL foto profilo"
                      : "URL foto/portfolio"
                }
                value={serviceForm.imageUrl}
                onChange={(value) => setServiceForm((prev) => ({ ...prev, imageUrl: value }))}
              />
              <PhotoUploadField
                label={
                  activeCategory === "decorazioni"
                    ? "Allega foto del negozio"
                    : activeCategory === "dj" || activeCategory === "fotografo"
                      ? "Allega foto profilo"
                      : "Allega foto/portfolio"
                }
                description={
                  photoUploading
                    ? "Caricamento su Supabase Storage…"
                    : activeCategory === "decorazioni"
                      ? "JPG/PNG/WebP, max 5 MB — salvate su cloud, come le location."
                      : activeCategory === "dj" || activeCategory === "fotografo"
                        ? "JPG/PNG/WebP, max 5 MB — foto profilo su cloud."
                        : "JPG/PNG/WebP, max 5 MB — immagine pubblicazione su cloud."
                }
                images={
                  serviceForm.galleryImageUrls.length > 0
                    ? serviceForm.galleryImageUrls
                    : serviceForm.uploadedImageUrl
                      ? [serviceForm.uploadedImageUrl]
                      : []
                }
                multiple={activeCategory === "decorazioni"}
                uploading={photoUploading}
                onAddPhotos={(files) => void addServicePhoto(files)}
                onRemovePhoto={removeServicePhoto}
              />
              <div className="grid gap-2 sm:grid-cols-2">
                <Button variant="outline" className="rounded-2xl" onClick={() => saveService(false)}>
                  Salva bozza
                </Button>
                <Button className="rounded-2xl" onClick={() => saveService(true)}>
                  {editingServiceId ? "Aggiorna e pubblica" : "Salva e pubblica"}
                </Button>
              </div>
              {editingServiceId && (
                <button
                  type="button"
                  onClick={resetServiceForm}
                  className="w-full text-center text-xs font-semibold text-primary-black/50 underline-offset-2 hover:underline"
                >
                  Annulla modifica e svuota form
                </button>
              )}
            </div>
        </section>

        <section className="min-w-0 rounded-[1.75rem] border border-primary-black/10 bg-primary-black/[0.02] p-4 sm:rounded-[2rem] sm:p-5">
          <div className="flex min-w-0 items-start justify-between gap-3">
            <div className="min-w-0">
              <h2 className="min-w-0 text-base font-black text-primary-black sm:text-lg">
                Le tue pubblicazioni
              </h2>
              <p className="mt-1 text-xs font-semibold text-primary-black/55">
                Memoria di{" "}
                {CATEGORIES.find((item) => item.id === activeCategory)?.label}:
                tocca Modifica per rivederle in qualsiasi momento.
              </p>
            </div>
            <span className="shrink-0 rounded-full bg-background px-3 py-1 text-xs font-bold text-primary-black/55">
              {liveCount}/{categoryListings.length} live
            </span>
          </div>
          <ul className="mt-4 space-y-3">
            {categoryListings.length === 0 && (
              <li className="rounded-2xl border border-dashed border-primary-black/15 bg-surface p-6 text-center text-sm text-primary-black/55">
                Nessuna pubblicazione salvata in questa categoria. Creane una a
                sinistra: resterà qui per modifiche future.
              </li>
            )}
            {categoryListings.map((listing) => {
              if (listing.category === "locali") return null;
              const status = getManagedListingStatus(listing);
              const isLive = status === "published";
              const isEditing = editingServiceId === listing.id;

              return (
              <li
                key={listing.id}
                className={cn(
                  "min-w-0 rounded-2xl border bg-surface p-4",
                  isEditing
                    ? "border-brand-teal ring-1 ring-brand-teal/30"
                    : "border-primary-black/10",
                )}
              >
                <div className="flex min-w-0 items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="break-words font-bold text-primary-black">
                      {listingName(listing)}
                    </p>
                    <p className="mt-1 text-xs text-primary-black/55">
                      {isLive ? "Pubblicato in Esplora" : "Bozza privata"} ·
                      Aggiornato{" "}
                      {new Date(listing.updatedAt).toLocaleDateString("it-IT")}
                    </p>
                  </div>
                  <span
                    className={cn(
                      "shrink-0 rounded-full px-3 py-1 text-xs font-bold",
                      isLive
                        ? "bg-brand-teal/10 text-brand-teal"
                        : "bg-primary-black/5 text-primary-black/45",
                    )}
                  >
                    {isLive ? "Live" : "Bozza"}
                  </span>
                </div>
                <div className="mt-3 grid gap-2 sm:grid-cols-3">
                  <button
                    type="button"
                    onClick={() => loadServiceListing(listing)}
                    className="flex min-w-0 items-center justify-center gap-2 rounded-xl border border-brand-teal/30 bg-brand-teal/10 px-3 py-2.5 text-xs font-bold text-brand-teal"
                  >
                    <Pencil className="h-3.5 w-3.5 shrink-0" aria-hidden />
                    Modifica
                  </button>
                  <button
                    type="button"
                    onClick={() => toggleManagedListingPublication(listing.id)}
                    className="flex min-w-0 items-center justify-center gap-2 rounded-xl border border-primary-black/10 px-3 py-2.5 text-xs font-bold text-primary-black/70"
                  >
                    {isLive ? (
                      <EyeOff className="h-3.5 w-3.5 shrink-0" aria-hidden />
                    ) : (
                      <Eye className="h-3.5 w-3.5 shrink-0" aria-hidden />
                    )}
                    <span className="truncate">
                      {isLive ? "Togli live" : "Pubblica"}
                    </span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const name = listingName(listing);
                      const confirmed = window.confirm(
                        `Eliminare la pubblicazione di “${name}”? Verrà rimossa da Esplora e dal catalogo.`,
                      );
                      if (!confirmed) return;
                      removeManagedListing(listing.id);
                      if (editingServiceId === listing.id) resetServiceForm();
                      setAiMessage(`Pubblicazione di “${name}” eliminata.`);
                    }}
                    className="flex min-w-0 items-center justify-center gap-2 rounded-xl border border-brand-pink/30 bg-brand-pink/10 px-3 py-2.5 text-xs font-bold text-brand-pink"
                  >
                    <Trash2 className="h-3.5 w-3.5 shrink-0" aria-hidden />
                    Elimina
                  </button>
                </div>
              </li>
              );
            })}
          </ul>
        </section>
      </div>
      )}
        </>
      )}
    </div>
  );
}

function PhotoUploadField({
  label,
  description,
  images,
  multiple = false,
  uploading = false,
  onAddPhotos,
  onRemovePhoto,
}: {
  label: string;
  description: string;
  images: string[];
  multiple?: boolean;
  uploading?: boolean;
  onAddPhotos: (files: FileList | null) => void;
  onRemovePhoto: (index: number) => void;
}) {
  return (
    <div className="min-w-0 rounded-3xl border border-primary-black/10 bg-primary-black/[0.02] p-4">
      <div className="flex min-w-0 items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-sm font-black text-primary-black">{label}</p>
          <p className="mt-1 text-xs leading-relaxed text-primary-black/55">
            {description}
          </p>
        </div>
        <label
          className={cn(
            "flex shrink-0 cursor-pointer items-center gap-1.5 rounded-2xl bg-brand-teal px-3 py-2 text-xs font-black text-ink-inverse transition-colors hover:bg-brand-teal/90",
            uploading && "pointer-events-none opacity-60",
          )}
        >
          <UploadCloud className="h-4 w-4" aria-hidden />
          {uploading ? "…" : "Carica"}
          <input
            type="file"
            accept="image/jpeg,image/png,image/webp,image/gif"
            multiple={multiple}
            disabled={uploading}
            className="sr-only"
            onChange={(event) => {
              onAddPhotos(event.target.files);
              event.target.value = "";
            }}
          />
        </label>
      </div>

      {images.length > 0 ? (
        <ul className="mt-3 grid min-w-0 grid-cols-2 gap-2 sm:grid-cols-3 sm:gap-3">
          {images.map((image, index) => (
            <li
              key={`${image.slice(0, 32)}-${index}`}
              className="relative min-w-0 overflow-hidden rounded-2xl border border-primary-black/10 bg-background"
            >
              <div className="relative aspect-[4/3]">
                <SafeImage
                  src={image}
                  alt={`${label} ${index + 1}`}
                  fill
                  className="object-cover"
                  sizes="160px"
                />
              </div>
              <button
                type="button"
                onClick={() => onRemovePhoto(index)}
                className="absolute right-2 top-2 flex h-7 w-7 items-center justify-center rounded-full bg-background text-primary-black/55 shadow-sm transition-colors hover:text-brand-pink"
                aria-label={`Rimuovi foto ${index + 1}`}
              >
                <X className="h-3.5 w-3.5" aria-hidden />
              </button>
              {index === 0 && (
                <span className="absolute bottom-2 left-2 rounded-full bg-paper px-2 py-1 text-[10px] font-black text-ink-inverse">
                  Copertina
                </span>
              )}
            </li>
          ))}
        </ul>
      ) : (
        <div className="mt-3 rounded-2xl border border-dashed border-primary-black/15 bg-background px-4 py-5 text-center">
          <Camera className="mx-auto h-5 w-5 text-primary-black/35" aria-hidden />
          <p className="mt-2 text-xs font-semibold text-primary-black/45">
            Nessuna foto allegata.
          </p>
        </div>
      )}
    </div>
  );
}

function FormInput({
  label,
  value,
  onChange,
  type = "text",
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  type?: string;
}) {
  return (
    <label className="block min-w-0">
      <span className="mb-1.5 block text-xs font-bold text-primary-black/55">
        {label}
      </span>
      <input
        type={type}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        className="w-full min-w-0 max-w-full rounded-2xl border border-primary-black/10 bg-background px-4 py-3 text-base outline-none focus:border-brand-teal"
      />
    </label>
  );
}

function FormTextarea({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
}) {
  return (
    <label className="block min-w-0">
      <span className="mb-1.5 block text-xs font-bold text-primary-black/55">
        {label}
      </span>
      <textarea
        value={value}
        onChange={(event) => onChange(event.target.value)}
        rows={4}
        className="w-full min-w-0 max-w-full resize-y rounded-2xl border border-primary-black/10 bg-background px-4 py-3 text-base outline-none focus:border-brand-teal"
      />
    </label>
  );
}
